package ar.edu.unlp.info.oo1.Ejercicio_8;

import java.util.ArrayList;
import java.util.List;

public class Distribuidora {
	
	private double precioKWh;
	private List<Usuario> usuarios;
	
	public Distribuidora(double precioKWh) {
		this.usuarios = new ArrayList<>();
		this.precioKWh = precioKWh;
	}
	public List<Usuario> getUsuarios() {
		return usuarios;
	}
	public void agregarUsuario(String nombre , String direccion) {
		Usuario  usuario = new Usuario(nombre,direccion);
		this.usuarios.add(usuario);
	}	
	public void registrarConsumo(double consumoEA, double consumoER,Usuario usuario) {
		Consumo consumo  = new Consumo(consumoEA,consumoER);
		usuario.agregarMedicion(consumo);
	}
	
	public void setPrecioKWh(double precio) {
		this.precioKWh = precio;
	}
	public double getPrecioKWH() {
		return this.precioKWh;
	}
	public List<Factura> facturar() {
		// TODO Auto-generated method stub
		List<Factura> facturas = new ArrayList<>();
		facturas=usuarios.stream().map(u -> u.facturarEnBaseA(this.precioKWh)).toList();
		return new ArrayList<Factura>(facturas);
	}
}
