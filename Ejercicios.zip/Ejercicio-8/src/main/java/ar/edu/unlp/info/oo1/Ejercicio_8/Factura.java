package ar.edu.unlp.info.oo1.Ejercicio_8;

import java.time.LocalDate;

public class Factura {
	
	private double montoEnergiaActiva;
	private double descuento;
	private LocalDate fecha;
	private Usuario usuario;
	public Factura() {
		// TODO Auto-generated constructor stub
		this.fecha = LocalDate.now();
	}
	public Factura(Usuario usuario , double montoEnergiaActiva,double descuento) {
		// TODO Auto-generated constructor stub
		this.fecha = LocalDate.now();
		this.descuento=descuento;
		this.montoEnergiaActiva = montoEnergiaActiva;
		this.usuario = usuario;
	}
	public double montoTotal() {
		return this.montoEnergiaActiva - this.descuento / this.montoEnergiaActiva*100 ;
		
	} 
	
		
	public double getMontoEnergiaActiva() {
		return montoEnergiaActiva;
	}
	public void setMontoEnergiaActiva(double montoEnergiaActiva) {
		this.montoEnergiaActiva = montoEnergiaActiva;
	}
	public double getDescuento() {
		return descuento;
	}
	public void setDescuento(double descuento) {
		this.descuento = descuento;
	}
	public LocalDate getFecha() {
		return fecha;
	}
	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public Usuario getUsuario() {
		//retorno uns copis del usuario
		//Casos en los que deberia hacerlo?
		return  this.usuario;
	}
	public LocalDate fecha() {
		// TODO Auto-generated method stub
		return this.fecha;
	}
	
	
}
	