package ar.edu.unlp.info.oo1.Ejercicio_8;

import java.util.ArrayList;
import java.util.List;

public class Usuario {
	private String domicilio;
	private String nombre;
	private List<Consumo> consumos;
	private List<Factura> facturas;
	
	
	//No devolver objetos con this 
	//ya que de esa forma devuelvo el objeto 
	//de forma que puede ser modificado 
	//usar new para enviar una copia
	
	public Usuario(String nombre,String direccion) {
		this.domicilio=direccion;
		this.nombre=nombre;
		this.consumos=new ArrayList<>();
		this.facturas=new ArrayList<>();
	}
	
	public 	void agregarMedicion(Consumo medicion) {
		this.consumos.add(medicion);
	}
	public double ultimoConsumoActiva() {
		if(this.consumos.size()>0) {
			return this.consumos.get(this.consumos.size()-1).getConsumoEnergiaActiva();
		}
		return 0;
	}
	
	
	//Factura en base a  PrecioKWH
	//retorno la factura actual o una factura ? 
	public Factura facturarEnBaseA(double precioKWh) {
		Consumo consumo = this.consumos.get(this.consumos.size()-1);
		double costo  = consumo.costoEnBaseA(precioKWh);
		double descuento = 0;
		if(consumo.factorDePotencia() > 0.8) {
			descuento =10;
		}
		
		return new Factura(this,costo,descuento);
	}
	public List<Consumo> getConsumos() {
		return new ArrayList<Consumo>(this.consumos); 
	}
	public List<Factura> getFacturas() {
		return new ArrayList<Factura>(this.facturas);
	}
	//la forma corecta de devolver una lista seria 
	//devolver una copia ya que si devuelvo this.lista
	//estaria devolviendo la lista de una forma en la que
	//quien la reciba fuera del metodo puede modificarla 
	//lo cual estaria mal  
	
	public List<Factura> facturas(){
		return  new ArrayList<>(this.facturas);
	}
	public String getDomicilio() {
		return this.domicilio;
	}
	public String getNombre() {
		return this.nombre;
	}
	
	
}
