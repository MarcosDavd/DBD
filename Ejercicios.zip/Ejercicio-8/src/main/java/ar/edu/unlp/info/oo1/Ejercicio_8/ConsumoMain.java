package ar.edu.unlp.info.oo1.Ejercicio_8;

public class ConsumoMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Consumo consumo = new Consumo(10, 10);
		//Rano 1 : 20,10
		//Rango 2 : 10,10
		System.out.println("Factor de potencia"+consumo.factorDePotencia() );
	}

}
