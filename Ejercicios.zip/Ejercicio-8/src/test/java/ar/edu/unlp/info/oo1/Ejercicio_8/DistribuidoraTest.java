package ar.edu.unlp.info.oo1.Ejercicio_8;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class DistribuidoraTest {
	
	private Distribuidora distribuidora;
	private Usuario usuario;
	private Consumo consumo;
	
	
	@BeforeEach
	void setUp() throws Exception{
		distribuidora = new Distribuidora(100); 
		usuario = new Usuario("David","238 y 67");
	}
	
	@Test 
	void testConstructor() {
		assertEquals(100, distribuidora.getPrecioKWH());
		assertTrue(distribuidora.getUsuarios().isEmpty());
	}
	
	@Test
	void agregarUsuarioTest() {
		distribuidora.agregarUsuario(usuario.getNombre(),usuario.getDomicilio());
		assertTrue(distribuidora.getUsuarios().get(0).getNombre().equals(usuario.getNombre()));
		assertTrue(distribuidora.getUsuarios().get(0).getDomicilio().equals(usuario.getDomicilio()));
	}
}
