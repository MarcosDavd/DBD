package ar.edu.unlp.info.oo1.Ejercicio_8;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ConsumoTest {
	private Consumo consumo;

	@BeforeEach
	void setUp() throws Exception {
		consumo = new Consumo(200,300);
	}
	@Test
	void constructorTest() {
		
	}
}
