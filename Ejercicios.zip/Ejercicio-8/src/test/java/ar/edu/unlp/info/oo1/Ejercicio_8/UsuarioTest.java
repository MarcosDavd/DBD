package ar.edu.unlp.info.oo1.Ejercicio_8;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class UsuarioTest {
	private Usuario usuario;
	private Consumo consumo1;
	private Consumo consumo2;
	@BeforeEach
	
//	Equals compara contenido de los objetos 
// == La identidad de ambos (direcciones de memoria)
	
	 void setUp() throws Exception {
		usuario = new Usuario("XXX","7 y 51");
		consumo1 = new Consumo(200, 100); //El factor de potencia es mayor a 0.8
		consumo2 = new Consumo(10,10);//El factor de potencia es menor a 0.8
	
	}
	@Test 
	void constructorTest() {
		// TODO Auto-generated method stub
		   
		assertTrue(usuario.getNombre().equals("XXX"));
		assertTrue(usuario.getDomicilio().equals("7 y 51"));
		assertTrue(usuario.getConsumos().isEmpty());
		assertTrue(usuario.getFacturas().isEmpty());
	}
	@Test
	void ultimoConsumoActivaTest(){		
		//Usuario sin Consumos
		assertEquals(usuario.ultimoConsumoActiva(),0);
		// Usuario con consumos
		usuario.agregarMedicion(consumo1);
		assertEquals(usuario.ultimoConsumoActiva(),consumo1.getConsumoEnergiaActiva());
		
		
	}
	@Test
	void facturarEnBaseA() {
		//facturas resultantes 
		
		usuario.agregarMedicion(consumo1);
		Factura f   =  usuario.facturarEnBaseA(1);
		assertSame(usuario,f.getUsuario());
		assertEquals(f.getDescuento(),10);
		assertEquals(f.getMontoEnergiaActiva(),200);

		
		usuario.agregarMedicion(consumo2);
		Factura f2 = usuario.facturarEnBaseA(1);
		assertSame(usuario,f.getUsuario());
		assertEquals(f2.getDescuento(),0);
		assertEquals(f2.getMontoEnergiaActiva(),10);

		
	}
	
	
}
