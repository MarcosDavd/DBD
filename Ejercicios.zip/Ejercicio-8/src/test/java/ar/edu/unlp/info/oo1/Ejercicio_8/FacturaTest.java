package ar.edu.unlp.info.oo1.Ejercicio_8;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class FacturaTest {
	
	private Factura factura1;
	private Factura factura2;
	private Usuario usuario;
	
	@BeforeEach
	void setUp() throws Exception{
		usuario = new Usuario("David","Poma");
		factura1 = new Factura(usuario,100, 10);
		factura2 = new Factura(usuario,10, 0);
	}
	
	
	@Test
	void constructorTest() {
		assertSame(usuario,factura1.getUsuario());
		
	}
	void 
}