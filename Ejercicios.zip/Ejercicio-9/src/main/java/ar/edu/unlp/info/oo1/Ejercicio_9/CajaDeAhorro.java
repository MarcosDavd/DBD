package ar.edu.unlp.info.oo1.Ejercicio_9;

public class CajaDeAhorro extends Cuenta {
	
	
	
	public CajaDeAhorro() {
		// TODO Auto-generated constructor stub
		super();
	}
	//
	@Override
	boolean puedeExtraer(double monto) {
		// TODO Auto-generated method stub
		if(this.getSaldo()>= monto) {
			return true;
		}else {
		return false;
		}
	}
	@Override
	public void depositar(double monto) {
		// TODO Auto-generated method stub
		super.depositar(monto-monto*0.02);//Desposito el monto
	}
	@Override
	public boolean extraer(double monto) {
		// TODO Auto-generated method stub		
		return super.extraer(monto*1.02);
	}
	@Override
	public boolean transferirACuenta(double monto, Cuenta cuentaDestino) {
		// TODO Auto-generated method stub
		return super.transferirACuenta(monto*1.02, cuentaDestino);
	}
	
}
