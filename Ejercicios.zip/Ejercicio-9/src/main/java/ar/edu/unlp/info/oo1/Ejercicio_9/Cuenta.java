package ar.edu.unlp.info.oo1.Ejercicio_9;

public abstract class Cuenta {
	
	private double saldo;
	
	
	//Constructor
	public Cuenta() {
		this.saldo=0;
	}
	
	//Retorna true si es posible extraer el saldo de la cuenta
	abstract boolean puedeExtraer(double monto);
	//Deposita un saldo en la cuenta
	public void depositar(double monto) {
		this.saldo+=monto;
	}
	//Si es posible extraer el monto realiza la accion
	// y retorna true 
	public boolean extraer(double monto) {
		if(this.puedeExtraer(monto)) {
			this.extraerSinControlar(monto);
			return true;
		}
		else {
			return false;
		}
	}
	//Extrae sin controlar el saldo
	protected void extraerSinControlar(double monto) {
		this.saldo -= monto;
	}
	//Si se puede extraer realiza la accion 
	// deposita el saldo en la CuentaDestino
	// y retorna true
	public boolean transferirACuenta(double monto , Cuenta cuentaDestino) {
		if(this.puedeExtraer(monto)) {
			this.extraerSinControlar(monto);
			cuentaDestino.depositar(monto);
			return true;
		}else {
			return false;
		}
	}
	
	public double getSaldo() {
		return saldo;
	}
}
