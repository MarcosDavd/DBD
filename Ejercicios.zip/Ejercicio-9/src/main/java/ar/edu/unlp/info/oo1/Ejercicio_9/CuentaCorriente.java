package ar.edu.unlp.info.oo1.Ejercicio_9;

public class CuentaCorriente extends Cuenta{
	
	private double descubierto;
	
	
	public CuentaCorriente() {
		// TODO Auto-generated constructor stub
		super();
		this.descubierto=0;
	}
	
	
	
	@Override
	boolean puedeExtraer(double monto) {
		// TODO Auto-generated method stub
		if((this.getSaldo() - monto) >= this.getDescubierto()) {
			return true;
		}else {
			return false;
		}
	}
	
	
	public double getDescubierto() {
		return descubierto;
	}
	public void setDescubierto(double descubierto) {
		this.descubierto = descubierto;
	}
	
}
