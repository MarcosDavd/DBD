package ar.edu.unlp.info.oo1.Ejercicio_14;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class DateLapse {
	private LocalDate from;
	private LocalDate to;
	
	
	
	
	
	//Retorna la cantiad de dias entre from y to
	public int sizeInDays() {
		long dias = ChronoUnit.DAYS.between(from,to);
		return (int) dias;
	}
	
	//Retorna true si la fecha other se encuentra from y to
	public boolean includesDate(LocalDate other) {
		return other.isAfter(from) && other.isBefore(to);
	}
	
	public LocalDate getFrom() {
		return from;
	}
	public void setFrom(LocalDate from) {
		this.from = from;
	}
	public LocalDate getTo() {
		return to;
	}
	public void setTo(LocalDate to) {
		this.to = to;
	}
	
	
	
	
	
}
