package ar.edu.unlp.info.oo1.Ejercicio_13;

import java.util.ArrayList;
import java.util.List;

public class Carpeta {
	private String nombre;
	private List<Email> emails;
	
	public Carpeta(String nombre) {
		this.nombre = nombre;
		this.emails = new ArrayList<>();
	}
	
	public Email retornarEmail(Email unEmail) {
		//busca el mail que se pasa parametro
		Email mail = this.emails.stream().filter(e -> e.equals(unEmail)).findFirst().orElse(null);
		this.emails.remove(mail);
		return mail;
	}
	public Email buscar(String titulo) {
		//Busca el primer email que contenga el titulo y lo
		//retorna	
		 Email email = this.emails.stream().filter(e -> e.getTitulo().contains(titulo)).findFirst().orElse(null);
		 return email;
	}
	public int calcularTamanio() {
		return this.emails.stream().mapToInt(email -> email.calcularTamanio()).sum();
	}
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public List<Email> getEmails() {
		return emails;
	}
	public void agregarMail(Email email) {
		this.emails.add(email);
	}
	public void remover(Email email) {
		this.emails.remove(email);
	}
	
}
