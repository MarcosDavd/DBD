package ar.edu.unlp.info.oo1.Ejercicio_13;

import java.util.List;

public class Email {
	private String titulo;
	private String cuerpo;
	private List<Archivo> adjuntos;
	
	public Email(String titulo,String cuerpo,List<Archivo> adjuntos) {
		this.titulo = titulo;
		this.cuerpo = cuerpo;
		this.adjuntos = adjuntos;
		//Consultar : si pasa algo con la lista de adjuntos
		//se borra tambien de Email ?
	}
	
	public int calcularTamanio() {
		return this.adjuntos.stream().mapToInt(archivo -> archivo.tamanio()).sum();
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getCuerpo() {
		return cuerpo;
	}
	public void setCuerpo(String cuerpo) {
		this.cuerpo = cuerpo;
	}
	public List<Archivo> getAdjuntos() {
		return adjuntos;
	}
	public void setAdjuntos(List<Archivo> adjuntos) {
		this.adjuntos = adjuntos;
	}
	
	
	
}
