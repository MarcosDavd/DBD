package ar.edu.unlp.info.oo1.Ejercicio_13;

import java.util.List;

public class ClienteDeCorreo {
	
	private List<Carpeta> carpetas;
	private Carpeta inbox;
	
	//Almacena en inbox (una de las carpetas)el email que recibe como parametro
	public void recibir(Email email) {
		this.inbox.agregarMail(email);
	}
	//Mueve el email que viene como paramtro de la cartpeta origen a la carpeta destino
	
	// Buscar el mail y retornarlo
	
	// eliminarlo de la carpeta origen
	
	// moverlo a la carpeta destino
	public void mover(Email email,Carpeta origen, Carpeta destino) {
		destino.agregarMail(origen.retornarEmail(email));
	}
	
	public Email buscar(String titulo) {
		Email email;
		//Busco si ha alguna carpeta ,
		Carpeta carpeta = this.carpetas.stream().filter(c -> c.buscar(titulo).getTitulo().equals(titulo)).findFirst().orElse(null);
		//Si encuentro la carpeta
		//busca el email en la carpeta y si lo encuetra lo retorna
		if(carpeta != null) {
			email = carpeta.buscar(titulo);
		}else {
			 email = this.inbox.buscar(titulo);
		}
		return email;
	}
	public int espacioOcupado() {
		return  this.carpetas.stream().mapToInt(c -> c.calcularTamanio()).sum() + this.inbox.calcularTamanio();
	}
}

