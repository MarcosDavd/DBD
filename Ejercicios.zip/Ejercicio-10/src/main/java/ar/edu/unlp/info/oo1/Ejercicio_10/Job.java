package ar.edu.unlp.info.oo1.Ejercicio_10;

public class Job {
	private int priority;
	private double effort;
	private String descripcion;
	public Job(double effort,int priority,String descripcion) {
		this.effort=effort;
		this.priority=priority;
		this.descripcion=descripcion;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public double getEffort() {
		return effort;
	}
	public void setEffort(double effort) {
		this.effort = effort;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	
}	
