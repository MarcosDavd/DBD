package ar.edu.unlp.info.oo1.Ejercicio_10;

import java.util.ArrayList;
import java.util.List;

public class JobScheduler {
    protected List<Job> jobs;
    protected Strategy strategy;

    public JobScheduler () {
        this.jobs = new ArrayList<>();
    }

    public void schedule(Job job) {
        this.jobs.add(job);
    }

    public void unschedule(Job job) {
        if (job != null) {
            this.jobs.remove(job);
        }
    }

    public Strategy getStrategy() {
        return this.strategy; 
    }

    public List<Job> getJobs(){
        return jobs;
    }

    public void setStrategy(Strategy strategy) {
        this.strategy = strategy;
    }
    public Job next() {
    	Job job = this.strategy.next(this.jobs);
    	this.unschedule(job);
    	return job;
    }

    
}


