package ar.edu.unlp.info.oo1.Ejercicio_10;

import java.util.List;

public interface Strategy {
	public abstract Job next(List<Job> job);
	
}
