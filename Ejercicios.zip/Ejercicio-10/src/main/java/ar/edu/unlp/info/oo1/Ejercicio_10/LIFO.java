package ar.edu.unlp.info.oo1.Ejercicio_10;

import java.util.List;

public class LIFO implements Strategy{

	@Override
	public Job next(List<Job> jobs) {
		// TODO Auto-generated method stub	
		Job nextJob = jobs.get(jobs.size());	
		return nextJob;
	}


}
