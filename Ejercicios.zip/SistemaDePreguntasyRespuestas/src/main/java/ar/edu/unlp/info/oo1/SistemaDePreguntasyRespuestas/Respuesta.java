package ar.edu.unlp.info.oo1.SistemaDePreguntasyRespuestas;

public class Respuesta {
	private Persona autor;
	private String respuesta;
	public Respuesta() {
		// TODO Auto-generated constructor stub
	}
}
