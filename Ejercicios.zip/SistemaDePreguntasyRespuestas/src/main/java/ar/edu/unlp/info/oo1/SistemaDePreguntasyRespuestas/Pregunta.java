package ar.edu.unlp.info.oo1.SistemaDePreguntasyRespuestas;

public abstract class Pregunta {
	private String pregunta,respuesta;
	private int votosPos,votosNeg;
	private Persona autor;
	public String getPregunta() {
		return pregunta;
	}
	public void setPregunta(String pregunta) {
		this.pregunta = pregunta;
	}
	public String getRespuesta() {
		return respuesta;
	}
	public void setRespuesta(String respuesta) {
		this.respuesta = respuesta;
	}
	public int getVotosPos() {
		return votosPos;
	}
	public void setVotosPos(int votosPos) {
		this.votosPos = votosPos;
	}
	public int getVotosNeg() {
		return votosNeg;
	}
	public void setVotosNeg(int votosNeg) {
		this.votosNeg = votosNeg;
	}
	public Persona getAutor() {
		return autor;
	}
	public void setAutor(Persona autor) {
		this.autor = autor;
	}
	
	public abstract Respuesta mejorRespuesta() {};
	
}
