package ar.edu.unlp.info.oo1.SistemaDePreguntasyRespuestas;

public class Sistema {

}
