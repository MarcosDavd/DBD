package ar.edu.unlp.info.oo1.Ejercicio_11;

public interface Inversion {
	public abstract double valorActual();
}
