package ar.edu.unlp.info.oo1.Ejercicio_11;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class PlazoFijo implements Inversion {
	private LocalDate fechaDeConstitucion;
	private double montoDepositado;
	private double porcentajeDeInteresDiario;
	
	public PlazoFijo() {
		
	}
	
	@Override
	public double valorActual() {
		// TODO Auto-generated method stub
		long dias = ChronoUnit.DAYS.between(fechaDeConstitucion, LocalDate.now());
		return this.montoDepositado + ((this.montoDepositado * this.porcentajeDeInteresDiario / 100)*dias);
	}
	
	
}
