package ar.edu.unlp.info.oo1.Ejercicio_19;

public class Producto {
	private double precio;
	private String descripcion;
	private String nombre;
	private Vendedor vendedor;
	private int stock;
	
	public Producto(String nombre,String descripcion,int stock,double precio,Vendedor vendedor) {
		
		this.descripcion = descripcion;
		this.nombre = nombre;
		this.precio = precio;
		this.stock = stock;
		this.vendedor = vendedor;
		// TODO Auto-generated constructor stub
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Vendedor getVendedor() {
		return vendedor;
	}

	public void setVendedor(Vendedor vendedor) {
		this.vendedor = vendedor;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}
	
	
}
