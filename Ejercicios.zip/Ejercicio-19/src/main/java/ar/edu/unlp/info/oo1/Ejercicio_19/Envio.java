package ar.edu.unlp.info.oo1.Ejercicio_19;

public interface Envio {
	public abstract double calcularPrecioEnvio(Cliente cliente,Producto producto);
}
