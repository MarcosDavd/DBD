package ar.edu.unlp.info.oo1.Ejercicio_19;

import java.util.ArrayList;
import java.util.List;

public class Sistema {
	private List<Cliente> clientes ;
	private List<Vendedor> vendedores;
	private List<Producto> productosEnVenta;
	private List<Pedido> pedidos ;
	
	public Sistema() {
		// TODO Auto-generated constructor stub
		this.clientes = new ArrayList<>();
		this.pedidos =new ArrayList<>();
		this.productosEnVenta= new ArrayList<>();
		this.vendedores = new ArrayList<>();
	}
	
	public Cliente registrarCliente(String nombre, Direccion direccion) {
		Cliente cliente = new Cliente(nombre,direccion);
		this.clientes.add(cliente);
		return cliente;
	}
	public Vendedor registrarVendedor(String nombre,Direccion direccion) {
		Vendedor vendedor = new Vendedor(nombre, direccion);
		this.vendedores.add(vendedor);
		return vendedor;
	}
	public Producto ponerEnVenta(String nombre,double precio ,String descripcion,int unidades, Vendedor vendedor) {
		Producto producto = new Producto(nombre,descripcion,unidades,precio,vendedor);
		this.productosEnVenta.add(producto);
		return producto;
	}
	public boolean crearPedido(Cliente cliente,Producto producto,int cantidadSolicitada,Pago pago,Envio envio) {
		// TODO Auto-generated method stub
		//EL producto recibido es el mismo que esta en la lista de productos 
		boolean ok=false;
			if(producto.getStock()>=cantidadSolicitada) {
				producto.setStock(producto.getStock()-cantidadSolicitada);
				ok=true;
				Pedido pedido = new Pedido(cliente,producto,cantidadSolicitada,pago,envio);
				this.pedidos.add(pedido);
			}else {
				ok=false;
			}
			return ok;
	}
}
