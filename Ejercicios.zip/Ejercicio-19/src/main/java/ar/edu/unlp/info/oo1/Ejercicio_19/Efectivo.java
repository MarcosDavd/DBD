package ar.edu.unlp.info.oo1.Ejercicio_19;

public class Efectivo implements Pago{

	@Override
	public double calcularPrecio(double precio) {
		// TODO Auto-generated method stub
		return 0;
	}

}
