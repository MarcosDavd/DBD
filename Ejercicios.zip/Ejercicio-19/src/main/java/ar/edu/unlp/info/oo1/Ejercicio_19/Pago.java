package ar.edu.unlp.info.oo1.Ejercicio_19;

public interface Pago {
	public abstract double calcularPrecio(double precio);
}
