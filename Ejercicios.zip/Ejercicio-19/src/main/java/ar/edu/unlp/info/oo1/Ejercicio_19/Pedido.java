package ar.edu.unlp.info.oo1.Ejercicio_19;

public class Pedido {

	private int cantidadSolicitada;
	private Producto producto;
	private Cliente cliente;
	private Pago pago;
	private Envio envio;
	
	public Pedido(Cliente cliente ,Producto producto , int cantidadSolicitada ,Pago pago, Envio envio) {
		// TODO Auto-generated constructor stub
		this.producto=producto;
		this.cliente=cliente;
		this.cantidadSolicitada=cantidadSolicitada;
		this.envio=envio;
		this.pago=pago;
		
	}
	
	public double calcularPrecioTotal() {
		return this.pago.calcularPrecio(producto.getPrecio())+this.envio.calcularPrecioEnvio(this.cliente,this.producto);
	}
}
