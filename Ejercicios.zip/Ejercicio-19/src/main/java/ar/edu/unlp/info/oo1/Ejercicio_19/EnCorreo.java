package ar.edu.unlp.info.oo1.Ejercicio_19;

public class EnCorreo implements Envio{

	@Override
	public double calcularPrecioEnvio(Cliente cliente,Producto producto) {
		// TODO Auto-generated method stub
		return 0;
	}

}
