package ar.edu.unlp.info.oo1.Ejercicio_19;

public class Direccion {
	
	
	public Direccion() {
		// TODO Auto-generated constructor stub
	}
	
	public int distanciaEntre(Direccion direccion1,Direccion direccion2) {
		return 100;
	}
}
