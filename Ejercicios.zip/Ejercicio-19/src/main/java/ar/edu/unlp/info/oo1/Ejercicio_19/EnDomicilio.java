package ar.edu.unlp.info.oo1.Ejercicio_19;

public class EnDomicilio implements Envio{

	@Override
	public double calcularPrecioEnvio(Producto producto) {
		// TODO Auto-generated method stub
		Direccion direccion = new Direccion();
		
		return direccion.distanciaEntre(direccion, direccion);
	}
	
	
}
