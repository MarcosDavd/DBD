package ar.edu.unlp.info.oo1.Ejercicio_19;

public class Cliente {
	private String nombre;
	private Direccion direccion;
	
	public Cliente(String nombre, Direccion direccion) {
		// TODO Auto-generated constructor stub
		this.direccion = direccion;
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Direccion getDireccion() {
		return direccion;
	}

	public void setDireccion(Direccion direccion) {
		this.direccion = direccion;
	}
	
}
	