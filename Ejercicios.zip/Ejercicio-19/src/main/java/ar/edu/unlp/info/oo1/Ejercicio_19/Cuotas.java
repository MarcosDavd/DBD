package ar.edu.unlp.info.oo1.Ejercicio_19;

public class Cuotas implements Pago{

	@Override
	public double calcularPrecio(double precio) {
		// TODO Auto-generated method stub
		return precio*1.2;
	}
	
}
