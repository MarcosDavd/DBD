package ar.edu.unlp.info.oo1.Ejercicio_6;

import java.util.ArrayList;
import java.util.List;

public class Farola {
	
	private List<Farola>neighbors ;
	private boolean state;
	
	
	public Farola() {
		// TODO Auto-generated constructor stub
		this.neighbors= new ArrayList<>();
		this.state=false;
	}
	
	public List<Farola> getNeighbors() {
		return this.neighbors;
	}

	public void setNeighbors(List<Farola> neighbors) {
		this.neighbors = neighbors;
	}

	public boolean isState() {
		return state;
	}

	public void setState(boolean state) {
		this.state = state;
	}

	public void turnOn() {
		// TODO Auto-generated method stub
		//Si la farola esta apagada
			//prender la Farola y propagar la accion con las vecinas
		if(!this.state){
			this.state=true;
			this.neighbors.stream().forEach(farola -> farola.turnOn());
		}		
	}
	public void turnOff() {
		// TODO Auto-generated method stub
		//Si la farola esta prendida
			//apagar la Farola y propagar la accion con las vecinas
		if(this.state){
			this.state=false;
			this.neighbors.stream().forEach(farola -> farola.turnOff());
		}		
		
	}
	
	public void setNeighbor(Farola otraFarola) {
		this.neighbors.add(otraFarola);
	}
	
	
	public void pairWithNeighbor(Farola otraFarola) {
		// TODO Auto-generated method stub
		this.neighbors.add(otraFarola);
		otraFarola.setNeighbor(this);
	}
	public boolean isOn() {
		// TODO Auto-generated method stub
		if(this.state) {
			return true;
		}else {
			return false;
		}
	}
}
