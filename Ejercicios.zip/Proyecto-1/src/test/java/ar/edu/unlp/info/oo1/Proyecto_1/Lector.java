package ar.edu.unlp.info.oo1.Proyecto_1;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.InputStream;
public class Lector {
	public static void main(String[] args) {
	
		 ClassLoader classLoader = Lector.class.getClassLoader();
	        InputStream inputStream = classLoader.getResourceAsStream("personas.json");

	        if (inputStream != null) {
	            try {
	                ObjectMapper objectMapper = new ObjectMapper();
	                JsonNode rootNode = objectMapper.readTree(inputStream);

	                JsonNode personasNode = rootNode.get("personas");
	                if (personasNode != null && personasNode.isArray()) {
	                    for (JsonNode persona : personasNode) {
	                        JsonNode nombreNode = persona.get("nombre");
	                        if (nombreNode != null) {
	                            String nombre = nombreNode.asText();
	                            System.out.println("Nombre: " + nombre);
	                        }
	                    }
	                }
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        } else {
	            System.err.println("No se pudo encontrar el archivo JSON 'personas.json'.");
	        }

	}
}
