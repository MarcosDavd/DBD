package ar.edu.unlp.info.oo1.Ejercicio_12;

public class Esfera extends Pieza{

	private int radio;
	
	public Esfera(String color , String material ,int radio) {
		super(color,material);
		this.radio = radio;
	}
	
	@Override
	public double volumenDeMaterial() {
		// TODO Auto-generated method stub
			return 4/3*Math.PI*Math.pow(this.radio,2);
		
	}

	@Override
	public double superficieDeColor() {
		// TODO Auto-generated method stub
			return 4*Math.PI*Math.pow(radio, 2);
		
	}
	public int getRadio() {
		return this.radio;
	}
	
	public void setRadio(int radio) {
		this.radio = radio;
	}
	
}
