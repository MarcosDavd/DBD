package ar.edu.unlp.info.oo1.Ejercicio_12;

import java.util.ArrayList;
import java.util.List;

public class ReporteDeConstruccion {
	
	private List<Pieza> piezas;
	
	public ReporteDeConstruccion() {
		// TODO Auto-generated constructor stub
		this.piezas=new ArrayList<>();
	}
	
	public double volumenDeMaterial(String unNombreDeMaterial) {
		return piezas.stream().filter(pieza -> pieza.getMaterial().equals(unNombreDeMaterial)).mapToDouble(pieza->pieza.volumenDeMaterial()).sum();
	}
	
	public double superficieDeColior(String unNombreDeColor) {
		return piezas.stream().filter(pieza -> pieza.getColor().equals(unNombreDeColor)).mapToDouble(pieza -> pieza.superficieDeColor()).sum();
	}
	
}
