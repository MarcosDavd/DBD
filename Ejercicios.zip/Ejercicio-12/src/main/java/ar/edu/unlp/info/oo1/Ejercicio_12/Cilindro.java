package ar.edu.unlp.info.oo1.Ejercicio_12;

public class Cilindro extends Pieza{
	private double radio;
	private double altura;
	public Cilindro(String color,String material,double radio,double altura) {
		super(color,material);
		this.altura = altura;
		this.radio = radio;
	}
	
	@Override
	public double volumenDeMaterial() {
		// TODO Auto-generated method stub
			return Math.PI * Math.pow(radio, 2) * this.altura ;
		
	}
	@Override
	public double superficieDeColor() {
		// TODO Auto-generated method stub
			return 2*Math.PI*this.radio*this.altura+2*Math.PI*Math.pow(radio, 2);
		
	}

	public double getRadio() {
		return radio;
	}

	public void setRadio(double radio) {
		this.radio = radio;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}
	
	
}
