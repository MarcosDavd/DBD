package ar.edu.unlp.info.oo1.Ejercicio_12;

public class PrismaRectangular extends Pieza {
	
	private int ladoMayor;
	private int ladoMenor;
	private int altura;
		
	public PrismaRectangular(String color , String material,int ladoMenor,int ladoMayor,int altura) {
		super(color,material);
		this.ladoMenor = ladoMenor;
		this.ladoMayor =  ladoMayor;
		this.altura = altura;
	}
	
	
	
	@Override
	public double volumenDeMaterial() {
		// TODO Auto-generated method stub
			return this.ladoMayor*this.ladoMenor*this.altura;
	}
	@Override
	public double superficieDeColor() {
		// TODO Auto-generated method stub
			return 2*(this.ladoMayor*this.ladoMenor+this.ladoMayor*this.altura*this.ladoMenor*this.altura);
	}



	public int getLadoMayor() {
		return ladoMayor;
	}



	public void setLadoMayor(int ladoMayor) {
		this.ladoMayor = ladoMayor;
	}



	public int getLadoMenor() {
		return ladoMenor;
	}



	public void setLadoMenor(int ladoMenor) {
		this.ladoMenor = ladoMenor;
	}



	public int getAltura() {
		return altura;
	}



	public void setAltura(int altura) {
		this.altura = altura;
	}
	
	
	
}
